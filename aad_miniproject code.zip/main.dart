import 'package:flutter/material.dart';
import 'button.dart';
import 'package:math_expressions/math_expressions.dart';
void main()
{
  runApp(MyCalculator());
}
class MyCalculator extends StatelessWidget {
  const MyCalculator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Homepage(),
    );
  }
}
class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  _HomepageState createState() => _HomepageState();
}
class _HomepageState extends State<Homepage> {
  var userinput='';
  var answer='';
  final List<String> buttons =[
    'C',
    '+/-',
    '%',
    'DEL',
    '7',
    '8',
    '9',
    '/',
    '4',
    '5',
    '6',
    'x',
    '1',
    '2',
    '3',
    '-',
    '0',
    '.',
    '=',
    '+',
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:new AppBar(
        title: Text("Calculator"),
      ),
      backgroundColor: Colors.white,
      body: Column(
        children: <Widget>[
          Expanded(
              child: Container(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: <Widget> [
                    Container(
                      padding: EdgeInsets.all(15),
                     alignment: Alignment.center,
                        child: Text(
                          answer,
                          style:TextStyle(
                            fontSize: 20,
                            color: Colors.teal,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                    )
                  ],
                ),
              ),
          ),
          Expanded(
            flex: 3,
            child: Container(
              child: GridView.builder(
                 itemCount: buttons.length,
                 gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                         crossAxisCount: 4,
                         ),
            itemBuilder: (BuildContext context, int index)
              {
                if(index==0)
                  {
                    return MyButton(
                    buttontapped: ()
                    {
                      setState((){
                        userinput='';
                        answer='0';
                    });
                    },
                  buttonText :buttons[index],
                    color: Colors.tealAccent,
                    textcolor: Colors.black,
                    );
                  }
                //+/- button
                else if(index==1)
                  {
                    return MyButton(
                    buttonText: buttons[index],
                    color: Colors.tealAccent,
                    textcolor:Colors.black ,
                    );
                  }
               // % Button
                else if(index==2)
                  {
                    return MyButton(
                    buttontapped:(){
                      setState(() {
                        userinput += buttons[index];
                      });
                  } ,
                  buttonText: buttons[index],
                  color: Colors.tealAccent,
                  textcolor:Colors.black ,
                    );
                  }
                //Delete
                 else if(index==3)
                   {
                     return MyButton(
                     buttontapped: (){
                       setState(() {
                         userinput = userinput.substring(0, userinput.length-1);
                   });
                   },
                   buttonText: buttons[index],
                   color: Colors.tealAccent,
                   textcolor:Colors.black ,
                     );
                   }
                 //=
                 else if(index==18)
                   {
                   return MyButton(
                   buttontapped: (){
                   setState(() {
                   equalPressed();
                   });
                   },
                   buttonText: buttons[index],
                   color: Colors.orange[700],
                   textcolor: Colors.black,
                   );
                   }
                 else
                   {
                     return MyButton(
                     buttontapped: (){
                   setState(() {
                     userinput += buttons[index];
                   });
                   },
                   buttonText: buttons[index],
                   color: isOperator(buttons[index])
                      ?Colors.tealAccent:
                      Colors.white,
                   textcolor: isOperator(buttons[index])
                       ?Colors.white
                       :Colors.black,
                     );
                   }
              },
              )
              ),
            ),
        ],
      ),
    );
  }
 bool isOperator(String x)
 {
   if(x== '/' || x=='x'|| x == '-' || x == '+' || x == '=')
     {
       return true;
     }
   return false;
 }
 void equalPressed()
 {
   String finaluserinput = userinput;
   finaluserinput = userinput.replaceAll('*','x');
   Parser p = Parser();
   Expression exp=p.parse(finaluserinput);
   ContextModel cm =ContextModel();
   double eval = exp.evaluate(EvaluationType.REAL, cm);
   answer = eval.toString();
 }
}


